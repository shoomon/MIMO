-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: mimodb.c95ejkmsx345.ap-northeast-2.rds.amazonaws.com    Database: s12p12a504
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `created_at` datetime(6) DEFAULT NULL,
  `last_modified_at` datetime(6) DEFAULT NULL,
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `account_number` varchar(13) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_nickname` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_profile_uri` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_status` enum('ACTIVE','INACTIVE') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UKr7e3xe2uqjaef83lw9tpmc8ql` (`user_nickname`),
  UNIQUE KEY `UKd4t5vk5oufhxosw60bxqut2vq` (`account_number`),
  UNIQUE KEY `UK33uo7vet9c79ydfuwg1w848f` (`user_email`),
  KEY `idx_user_id_accountNumber` (`user_id`,`account_number`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('2025-02-20 16:44:03.638575','2025-02-20 16:44:03.638575',1,'1002696878728','TICE PRAC','hjdroVeDMK8JXXM16CXr','kciimnida@gmail.com','https://lh3.googleusercontent.com/a/ACg8ocKferjitVS6W1Sj3kp3CfFPAulVVX7v9-DuqDfSs5EzpsXIJ_c=s96-c','ACTIVE'),('2025-02-20 16:55:57.723971','2025-02-20 16:55:57.723971',2,'1002149504935','_주원','g7K8GuWeKr1ZzGEtaiBW','tjwndnjs8@gmail.com','https://lh3.googleusercontent.com/a/ACg8ocLk6IjelzwK9vKdr7HRvKPGrhoxd_mQnQGs399-weFUOsCzdVw=s96-c','ACTIVE'),('2025-02-20 16:59:36.550398','2025-02-20 16:59:36.550398',3,'1002481881233','Jong myeong Kim','yWsW8TUmiE2b0uSirWou','kjm970304@gmail.com','https://lh3.googleusercontent.com/a/ACg8ocJZJVDvrGeT6e-wNPc7Rn61KJwCKtZ7FEiCBHfqJmXFAWsA6g=s96-c','ACTIVE'),('2025-02-20 17:05:46.806904','2025-02-20 17:05:46.806904',4,'1002507294367','서주원[서울_5반_A504]팀원','SujUM4tR2eKHBtZZC7ZL','tjwndnjs7@naver.com','https://lh3.googleusercontent.com/a/ACg8ocJM2lK4U74yXMgVBUIT5swnniLFcDTkRikaEl-YAvKRKfN-Aw=s96-c','ACTIVE'),('2025-02-20 17:16:30.384132','2025-02-20 17:16:30.384132',5,'1002951084494','spam spam','GOFBw6BxPTm11a6xBimF','tjwndnjs6@gmail.com','https://lh3.googleusercontent.com/a/ACg8ocIdQbb0oRBQtUYeFpXKJKQtR_w73H6mgBbh1jwMRXKpa5bAyQ=s96-c','ACTIVE'),('2025-02-20 17:22:50.535216','2025-02-20 17:22:50.535216',6,'1002773307180','김수민','S5iL0RN8E5byLvRniAeA','kate010117@gmail.com','https://lh3.googleusercontent.com/a/ACg8ocIkbAJYBPq3AJksZxdKYXwovLR-9GLmozMKtQ5NGw1LWPi1Bw=s96-c','ACTIVE'),('2025-02-20 17:52:50.575722','2025-02-20 17:52:50.575722',7,'1000123456789','admin','admin','admin','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','ACTIVE'),('2025-02-20 18:45:45.982245','2025-02-20 18:45:45.982245',8,'1002892907593','admin2','admin2','admin2','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','ACTIVE'),('2025-02-20 19:54:34.679480','2025-02-20 19:54:34.679480',9,'1002457597574','admin3','admin3','admin3','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','ACTIVE'),(NULL,NULL,10,NULL,'','',NULL,'',NULL),('2025-02-20 12:21:19.629440','2025-02-20 12:21:19.629440',11,'1002511125780','박경범','uXXLXKLEypaLXKd8L7dM','gyoungbeom98@gmail.com','https://lh3.googleusercontent.com/a/ACg8ocJCbo09M8mG1qjHlENXD_YDlqqc55V-jKKHB1WfmINiLDPVU6on=s96-c','ACTIVE'),('2025-02-20 12:25:28.630805','2025-02-20 12:25:28.630805',12,'1002340107332','백명규','5uKWIls0ajLVYNOTUjyE','qoraudrb123@gmail.com','https://lh3.googleusercontent.com/a/ACg8ocK91KjkrH-CAPLL6ppTbghGfcudOz2iO01lbcSBh9ktRrNnfg=s96-c','ACTIVE'),('2025-02-20 12:38:14.225373','2025-02-20 12:38:14.225373',13,'1002613757197','mu moo','mlgynC8aSpFcLsv6QDg0','moomu.like@gmail.com','https://lh3.googleusercontent.com/a/ACg8ocL4g-uMf-RPjjznbu2bOkHpGM4L7ijCGb27yOmHc6LQYTjf2g=s96-c','ACTIVE'),('2025-02-20 14:59:07.562140','2025-02-20 14:59:07.562140',14,'1002886995644','윤다은','RKMxTAQbJtsYHzBci6kt','syoon4486@gmail.com','https://lh3.googleusercontent.com/a/ACg8ocJFAsX-twnSxUssTAfsO_tco4qwYJ60jkmb_GhOn_e2gC-rWg=s96-c','ACTIVE'),('2025-02-20 15:58:10.885321','2025-02-20 15:58:10.885321',15,'1002790305555','김혜준(문과대학 사학)','j6hGb6ur1twEtC6TJZPA','charliekhj223@yonsei.ac.kr','https://lh3.googleusercontent.com/a/ACg8ocI-SFdVgAvBqWdMSym0Ncs7VKiotVXPW8pC-8B08gHnAvS6Ng=s96-c','ACTIVE'),('2025-02-20 16:08:12.469879','2025-02-20 16:08:12.469879',16,'1002299684139','감자단','OThYUIkXnDHwceupeI3B','potatossafy@gmail.com','https://lh3.googleusercontent.com/a/ACg8ocL2KHZXNpulRR-gAdWvScJxM35t0gWXVCahENTv-IQz91Q2cQ=s96-c','ACTIVE'),('2025-02-20 16:17:11.899085','2025-02-20 16:17:11.899085',17,'1002522041243','서주원','zPS4oDJhHh9K3vZDZNJK','kciimnida1@gmail.com','https://lh3.googleusercontent.com/a/ACg8ocJAfKA_ei_ZtyZFJ5GrWqH84rMZhPWJRC4pcKv-hExovhKjRw=s96-c','ACTIVE');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  2:38:36
