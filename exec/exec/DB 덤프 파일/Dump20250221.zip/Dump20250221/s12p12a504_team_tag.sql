-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: mimodb.c95ejkmsx345.ap-northeast-2.rds.amazonaws.com    Database: s12p12a504
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `team_tag`
--

DROP TABLE IF EXISTS `team_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_tag` (
  `team_id` bigint NOT NULL,
  `team_tag_id` bigint NOT NULL AUTO_INCREMENT,
  `tag_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`team_tag_id`),
  UNIQUE KEY `UK_team_user` (`tag_name`,`team_id`),
  KEY `idx_team_tag_name` (`team_id`,`tag_name`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_tag`
--

LOCK TABLES `team_tag` WRITE;
/*!40000 ALTER TABLE `team_tag` DISABLE KEYS */;
INSERT INTO `team_tag` VALUES (17,81,'게임'),(20,90,'게임'),(21,92,'게임'),(5,22,'경기도'),(6,28,'경기도'),(8,38,'경기도'),(19,88,'고기가먹고싶다'),(5,72,'김치'),(6,75,'김치치'),(6,76,'김치치치'),(6,77,'김치치치치'),(6,79,'나비'),(13,64,'독서'),(18,83,'독서'),(6,78,'마마마'),(19,87,'만화고기'),(6,27,'바이크'),(8,37,'바이크'),(5,21,'반려동물'),(7,30,'반려동물'),(9,40,'반려동물'),(12,57,'반려동물'),(14,71,'반려동물'),(16,74,'반려동물'),(3,6,'사진'),(7,29,'서울'),(9,39,'서울'),(14,70,'서울'),(16,73,'서울'),(18,82,'서울'),(19,84,'서울'),(20,89,'서울'),(21,91,'서울'),(25,99,'서울'),(26,101,'서울'),(28,105,'세종특별자치시'),(19,86,'스테이크'),(1,2,'요리'),(2,4,'요리'),(4,8,'요리'),(13,69,'요리'),(19,85,'요리'),(25,100,'요리'),(28,106,'음악'),(17,80,'제주특별자치도'),(13,67,'집가'),(2,3,'충청남도'),(4,7,'충청남도'),(13,68,'충청남도'),(1,1,'충청북도'),(3,5,'충청북도'),(26,102,'헬스');
/*!40000 ALTER TABLE `team_tag` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  2:38:28
