-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: mimodb.c95ejkmsx345.ap-northeast-2.rds.amazonaws.com    Database: s12p12a504
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `account_transaction`
--

DROP TABLE IF EXISTS `account_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_transaction` (
  `amount` bigint NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `transaction_id` bigint NOT NULL AUTO_INCREMENT,
  `imp_uid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `memo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `merchant_uid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receiver_account_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sender_account_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_category` enum('CHARGE','DEPOSIT','PAYMENT','TRANSFER') COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_status` enum('FAIL','PENDING','SUCCESS') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `idx_sender_tx_status` (`sender_account_number`,`transaction_status`),
  KEY `idx_receiver_tx_status` (`receiver_account_number`,`transaction_status`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_transaction`
--

LOCK TABLES `account_transaction` WRITE;
/*!40000 ALTER TABLE `account_transaction` DISABLE KEYS */;
INSERT INTO `account_transaction` VALUES (1000,'2025-02-20 19:51:40.949006',1,'imp_811678915713','충전','20250220-q1y8kayw','1002481881233',NULL,'CHARGE','FAIL'),(1000,'2025-02-20 19:59:01.344408',2,'imp_959113672889','충전','20250220-b3jg6og5','1002481881233',NULL,'CHARGE','SUCCESS'),(1000,'2025-02-20 20:05:20.862434',3,'imp_406497524597','충전','20250220-6fh0bda6','1002481881233',NULL,'CHARGE','SUCCESS'),(100,'2025-02-20 20:37:29.817437',4,NULL,'바나나우유',NULL,'1002481881233','1002481881233','PAYMENT','SUCCESS'),(100,'2025-02-20 12:30:16.907101',5,'imp_637584170168','충전','20250220-uzj324l2','1002511125780',NULL,'CHARGE','SUCCESS'),(100,'2025-02-20 12:39:20.608042',6,NULL,'바나나우유',NULL,'1002511125780','1002511125780','PAYMENT','SUCCESS'),(100,'2025-02-20 12:51:42.165430',7,'imp_737876076541','충전','20250220-9vshrr96','1002481881233',NULL,'CHARGE','SUCCESS'),(100,'2025-02-20 12:51:46.052230',8,'imp_022751820748','충전','20250220-fdkywghe','1002511125780',NULL,'CHARGE','SUCCESS'),(100,'2025-02-20 12:51:51.280650',9,'imp_547756739532','충전','20250220-q6qwl5ns','1002340107332',NULL,'CHARGE','SUCCESS'),(10000,'2025-02-20 12:51:58.438719',10,'imp_076783351654','충전','20250220-hx60dnbc','1002773307180',NULL,'CHARGE','FAIL'),(100,'2025-02-20 16:33:15.070633',11,'imp_500134006367','충전','20250221-6j97epkr','1002299684139',NULL,'CHARGE','SUCCESS');
/*!40000 ALTER TABLE `account_transaction` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  2:38:37
