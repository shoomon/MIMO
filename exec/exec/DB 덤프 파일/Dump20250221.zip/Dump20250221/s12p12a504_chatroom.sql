-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: mimodb.c95ejkmsx345.ap-northeast-2.rds.amazonaws.com    Database: s12p12a504
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `chatroom`
--

DROP TABLE IF EXISTS `chatroom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chatroom` (
  `chatroom_id` bigint NOT NULL AUTO_INCREMENT,
  `team_id` bigint DEFAULT NULL,
  `user_id` bigint NOT NULL,
  `chatroom_title` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_uri` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chatroom_status` enum('GROUP','PSP') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`chatroom_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chatroom`
--

LOCK TABLES `chatroom` WRITE;
/*!40000 ALTER TABLE `chatroom` DISABLE KEYS */;
INSERT INTO `chatroom` VALUES (1,1,1,'제목머모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/04cf9383-0efc-4dcc-8857-0bde1eaee6c9.webp','GROUP'),(2,2,2,'하이요모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/25b9b98e-2d0e-48d6-941b-cb68e3774b88.webp','GROUP'),(3,3,2,'나의 모임모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/c0a0372b-48f9-4de9-bd79-38c2a8c74645.webp','GROUP'),(4,4,2,'만든다모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/91914b6a-52ec-4d08-a4af-d1c3e063069a.webp','GROUP'),(5,5,1,'디비가자꾸날아가나으유모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/f56e5bd6-c6ba-4f78-b6ab-2f59e927cf2c.png','GROUP'),(6,6,1,'가명규가다라   명가나가나 다규명규모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/bb98ebd6-de51-48d9-bfe9-04f02ffbe3d8.png','GROUP'),(7,7,7,'명규명규모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','GROUP'),(8,8,7,'경범 경범모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/8832cb27-1000-4ead-a89e-a75cb2beb52b.jpg','GROUP'),(9,9,7,'명규 명규모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','GROUP'),(10,12,7,'명규명규다구리모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/b9d7c84b-e7b1-43d4-bd2d-9d9fbd47a651.jpg','GROUP'),(11,13,7,'명규명규 다구리 미안하다아아모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/9073ac31-e687-44b8-a19c-d59d112e6208.jpg','GROUP'),(12,14,7,'유저닉네임변경테스트모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','GROUP'),(13,16,8,'MEMBER도 되는지 테스트모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','GROUP'),(14,17,11,'범고래모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/ad266692-62c9-4711-8ca3-0546d789ae33.png','GROUP'),(15,18,13,'감자단모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','GROUP'),(16,19,12,'육식을 좋아하는 사람들모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/8e703b20-7cb1-4a3a-896b-783406c3a833.jpg','GROUP'),(17,20,14,'뜨개질함뜨까모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/5e24be5f-d408-4207-8c8f-11e5e7b283fb.png','GROUP'),(18,21,14,'아이언만들어와모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/baeb974e-75d8-4200-8969-0cd98cb26cc8.jpg','GROUP'),(19,25,6,'내가 만든 쿠키모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/42a90caf-ee23-4991-9b9d-aa0d896e9c57.jpg','GROUP'),(20,26,1,'헬스한판뜨실분모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/76777a66-9ec9-465c-8d9c-f4a949b39a0c.webp','GROUP'),(21,28,6,'비밀스런모임모임의 채팅방','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/14f86304-4ec7-4194-9f23-08f056e01631.jpg','GROUP');
/*!40000 ALTER TABLE `chatroom` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  2:38:32
