-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: mimodb.c95ejkmsx345.ap-northeast-2.rds.amazonaws.com    Database: s12p12a504
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `created_at` datetime(6) DEFAULT NULL,
  `max_capacity` bigint NOT NULL,
  `team_chatroom_id` bigint NOT NULL,
  `team_description_id` bigint DEFAULT NULL,
  `team_id` bigint NOT NULL AUTO_INCREMENT,
  `team_leader_id` bigint NOT NULL,
  `team_round` bigint DEFAULT NULL,
  `team_account_number` varchar(13) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_description` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_profile_uri` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `private_status` enum('PRIVATE','PUBLIC') COLLATE utf8mb4_unicode_ci NOT NULL,
  `recruit_status` enum('ACTIVE_PRIVATE','ACTIVE_PUBLIC','INACTIVE') COLLATE utf8mb4_unicode_ci NOT NULL,
  `team_area_code` enum('CHUNGCHEONG_NORTH','CHUNGCHEONG_SOUTH','GANGWON','GYEONGGI','GYEONGSANG_NORTH','GYEONGSANG_SOUTH','JEJU','JEOLLA_NORTH','JEOLLA_SOUTH','SEJONG','SEOUL') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_category` enum('BIKE','BOOK','CAR','COOK','GAME','HEALTH','MUSIC','PET','PHOTO','SPORTS') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`team_id`),
  UNIQUE KEY `UKsob22siqdnn2rfsxk6f00pgwb` (`team_name`),
  UNIQUE KEY `UKaoqvdhhepx1i4jfl0pjipg85m` (`team_description_id`),
  KEY `idx_status_area_team` (`private_status`,`team_area_code`,`team_id` DESC),
  KEY `idx_status_category_team` (`private_status`,`team_category`,`team_id` DESC),
  KEY `idx_team_id_accountNumber` (`team_id`,`team_account_number`),
  KEY `idx_team_round` (`team_round`),
  FULLTEXT KEY `team_name` (`team_name`),
  CONSTRAINT `FKka7fh4pvn6pysfs6a4udy8sjn` FOREIGN KEY (`team_description_id`) REFERENCES `team_description` (`team_description_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES ('2025-02-20 16:46:15.920514',10,0,1,1,1,NULL,'1001381543663','제목머','설명ㅇ...','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/04cf9383-0efc-4dcc-8857-0bde1eaee6c9.webp','PUBLIC','ACTIVE_PUBLIC','CHUNGCHEONG_NORTH','COOK'),('2025-02-20 17:02:22.288613',10,0,2,2,2,NULL,'1001694268877','하이요','바이요...','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/25b9b98e-2d0e-48d6-941b-cb68e3774b88.webp','PUBLIC','ACTIVE_PUBLIC','CHUNGCHEONG_SOUTH','COOK'),('2025-02-20 17:04:49.122258',10,0,3,3,2,NULL,'1001980578444','나의 모임','나의 모임...','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/c0a0372b-48f9-4de9-bd79-38c2a8c74645.webp','PUBLIC','ACTIVE_PUBLIC','CHUNGCHEONG_NORTH','PHOTO'),('2025-02-20 17:15:59.755948',10,0,4,4,2,NULL,'1001217800893','만든다','ㅁㄴㅇ...','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/91914b6a-52ec-4d08-a4af-d1c3e063069a.webp','PUBLIC','ACTIVE_PRIVATE','CHUNGCHEONG_SOUTH','COOK'),('2025-02-20 17:17:10.672913',10,0,5,5,1,NULL,'1001572962477','디비가자꾸날아가나으유','디비가 자꾸 날아가나...','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/f56e5bd6-c6ba-4f78-b6ab-2f59e927cf2c.png','PUBLIC','ACTIVE_PUBLIC','GYEONGGI','PET'),('2025-02-20 17:45:49.342239',10,0,6,6,1,NULL,'1001358220829','가명규가다라   명가나가나 다규명규','명규...','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/bb98ebd6-de51-48d9-bfe9-04f02ffbe3d8.png','PUBLIC','ACTIVE_PUBLIC','GYEONGGI','BIKE'),('2025-02-20 17:53:16.680176',100,0,7,7,7,NULL,'1001616637891','명규명규','명규명규...','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','PUBLIC','ACTIVE_PUBLIC','SEOUL','PET'),('2025-02-20 17:53:31.121035',100,0,8,8,7,NULL,'1001179606385','경범 경범','경범경범범...','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/8832cb27-1000-4ead-a89e-a75cb2beb52b.jpg','PUBLIC','ACTIVE_PUBLIC','GYEONGGI','BIKE'),('2025-02-20 17:58:15.378652',100,0,9,9,7,NULL,'1001340440245','명규 명규','명규 명규...','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','PUBLIC','ACTIVE_PUBLIC','SEOUL','PET'),('2025-02-20 17:58:26.842615',100,0,12,12,7,NULL,'1001736943215','명규명규다구리','경범경범...','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/b9d7c84b-e7b1-43d4-bd2d-9d9fbd47a651.jpg','PUBLIC','ACTIVE_PUBLIC','CHUNGCHEONG_NORTH','PET'),('2025-02-20 18:20:04.568394',100,0,13,13,7,NULL,'1001589331997','명규명규 다구리 미안하다아아','경범경범...','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/9073ac31-e687-44b8-a19c-d59d112e6208.jpg','PUBLIC','ACTIVE_PUBLIC','CHUNGCHEONG_SOUTH','COOK'),('2025-02-20 18:44:51.575747',100,0,14,14,7,NULL,'1001732305910','유저닉네임변경테스트','유저닉네임변경테스트...','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','PUBLIC','ACTIVE_PUBLIC','SEOUL','PET'),('2025-02-20 19:54:25.063137',100,0,16,16,8,NULL,'1001999282052','MEMBER도 되는지 테스트','MEMBER도 되는지 테스트...','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','PUBLIC','ACTIVE_PUBLIC','SEOUL','PET'),('2025-02-20 12:35:27.146881',1000,0,21,17,11,NULL,'1001295117475','범고래','A504-TOKEN...','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/ad266692-62c9-4711-8ca3-0546d789ae33.png','PUBLIC','ACTIVE_PRIVATE','JEJU','GAME'),('2025-02-20 12:55:12.577240',10,0,22,18,13,NULL,'1001389867250','감자단','감자감자빼겐두...','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','PUBLIC','ACTIVE_PUBLIC','SEOUL','BOOK'),('2025-02-20 12:58:14.007448',20,0,23,19,12,NULL,'1001857220704','육식을 좋아하는 사람들','마음이 고기고기...','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/8e703b20-7cb1-4a3a-896b-783406c3a833.jpg','PUBLIC','ACTIVE_PUBLIC','SEOUL','COOK'),('2025-02-20 15:01:01.261607',20,0,24,20,14,NULL,'1001208040709','뜨개질함뜨까','뜨개질 하며 함께 힐링해요~...','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/5e24be5f-d408-4207-8c8f-11e5e7b283fb.png','PUBLIC','ACTIVE_PUBLIC','SEOUL','GAME'),('2025-02-20 15:02:25.594842',100,0,25,21,14,NULL,'1001963968533','아이언만들어와','함께 성장하는 모임. 브론즈 이상은 들어오실 수 없습니다. 브론즈 되시면 나가주세요....','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/baeb974e-75d8-4200-8969-0cd98cb26cc8.jpg','PUBLIC','ACTIVE_PUBLIC','SEOUL','GAME'),('2025-02-20 15:40:06.673530',15,0,29,25,6,NULL,'1001239728555','내가 만든 쿠키','안녕하세요. 베이킹 모임입니다!...','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/42a90caf-ee23-4991-9b9d-aa0d896e9c57.jpg','PUBLIC','ACTIVE_PUBLIC','SEOUL','COOK'),('2025-02-20 16:04:44.401234',100,0,30,26,1,NULL,'1001742074418','헬스한판뜨실분','헬스 한판 뜨실 분을 구하는 모임입니다....','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/76777a66-9ec9-465c-8d9c-f4a949b39a0c.webp','PUBLIC','ACTIVE_PUBLIC','SEOUL','HEALTH'),('2025-02-20 16:28:20.510647',30,0,32,28,6,NULL,'1001205304209','비밀스런모임','PRIVATE한 모임입니다. 다들 나가주세요....','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/14f86304-4ec7-4194-9f23-08f056e01631.jpg','PRIVATE','ACTIVE_PUBLIC','SEJONG','MUSIC');
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  2:38:30
