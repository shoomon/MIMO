-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: mimodb.c95ejkmsx345.ap-northeast-2.rds.amazonaws.com    Database: s12p12a504
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `board_image`
--

DROP TABLE IF EXISTS `board_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_image` (
  `board_id` bigint NOT NULL,
  `board_image_id` bigint NOT NULL AUTO_INCREMENT,
  `team_board_id` bigint NOT NULL,
  `team_id` bigint NOT NULL,
  `file_extension` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_uri` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`board_image_id`),
  KEY `idx_board` (`board_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_image`
--

LOCK TABLES `board_image` WRITE;
/*!40000 ALTER TABLE `board_image` DISABLE KEYS */;
INSERT INTO `board_image` VALUES (5,1,13,16,'jpg','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/f80c0e8c-0fd7-435e-8d0e-d8f4bfa0ffbd.jpg'),(6,2,13,16,'jpg','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/ade9a57e-df73-482d-9bb2-ae3962462262.jpg'),(6,3,13,16,'jpg','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/ad44e4a8-6300-4d90-93aa-e9e57650f820.jpg'),(7,6,13,16,'jpg','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/fb12827e-b28d-4962-9e5e-f61760ea306f.jpg'),(8,7,18,19,'jpg','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/0406ecae-0fd3-419f-8863-b49d54cff2a7.jpg'),(9,8,20,20,'jpg','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/e77c49c2-3bcc-418b-8084-206f0d380673.jpg'),(10,9,20,20,'jpg','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/92ec64c1-f5a4-4e4f-a304-a79d9107ef7c.jpg'),(11,10,17,20,'jpg','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/d1633fdf-a3a8-4cae-8f04-9d01734440b6.jpg'),(12,11,18,19,'jpg','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/6def5433-7fe4-4586-9e34-e9984c8faa49.jpg'),(13,12,18,19,'jpg','https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/9fa3eb19-9804-4804-98bb-370c74a8f3cd.jpg');
/*!40000 ALTER TABLE `board_image` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  2:38:29
