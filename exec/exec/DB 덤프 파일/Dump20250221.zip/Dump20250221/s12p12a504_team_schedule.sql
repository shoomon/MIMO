-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: mimodb.c95ejkmsx345.ap-northeast-2.rds.amazonaws.com    Database: s12p12a504
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `team_schedule`
--

DROP TABLE IF EXISTS `team_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_schedule` (
  `created_at` datetime(6) DEFAULT NULL,
  `current_participants` bigint NOT NULL,
  `date` datetime(6) NOT NULL,
  `last_modified_at` datetime(6) DEFAULT NULL,
  `max_participants` bigint NOT NULL,
  `price` bigint NOT NULL,
  `team_id` bigint NOT NULL,
  `team_schedule_id` bigint NOT NULL AUTO_INCREMENT,
  `team_user_id` bigint NOT NULL,
  `short_description` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `schedule_status` enum('AD_HOC','CLOSED','REGULAR') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`team_schedule_id`),
  KEY `idx_schedule_team_id` (`team_id`),
  KEY `idx_schedule_status_date` (`schedule_status`,`date` DESC)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_schedule`
--

LOCK TABLES `team_schedule` WRITE;
/*!40000 ALTER TABLE `team_schedule` DISABLE KEYS */;
INSERT INTO `team_schedule` VALUES ('2025-02-20 18:07:52.729601',1,'2025-02-20 18:09:00.000000','2025-02-20 18:09:00.043075',1,1,6,1,6,'...','하나','하나','하나','CLOSED'),('2025-02-20 18:08:04.966665',1,'2025-02-20 18:09:00.000000','2025-02-20 18:09:00.107075',1,1,6,2,6,'...','하나','하나','하나','CLOSED'),('2025-02-20 18:09:31.454814',1,'2025-02-20 18:10:00.000000','2025-02-20 18:10:00.040145',1,0,6,3,6,'...','하나','하나','하나','CLOSED'),('2025-02-20 18:15:30.636581',1,'2025-02-20 18:17:00.000000','2025-02-20 18:17:00.033056',1,1,6,4,6,'...','ㅎㅇ','32','ㅎㅇ','CLOSED'),('2025-02-20 19:57:20.521263',1,'2025-02-19 20:48:00.000000','2025-02-20 10:57:40.059636',1000,10000,16,5,18,'...','명규 테스트용 정기모임','멀티캠퍼스','테스트용 정기모임','CLOSED'),('2025-02-20 20:38:39.680616',1,'2025-02-20 20:39:00.000000','2025-02-20 20:39:00.197890',12,1222,6,6,21,'...','번개썬더','ㅎㅇ','야오야오','CLOSED'),('2025-02-20 15:33:45.592232',0,'2025-02-22 15:00:00.000000','2025-02-20 16:10:07.311097',10,10000,20,7,35,'...','뜨뜨방 3차 정기 모임','투썸플레이스 역삼성홍타워점','토요일 3시 역삼역에서 진행합니다.\n참석비 10000원 있습니다~~','AD_HOC'),('2025-02-20 16:05:52.499797',1,'2025-02-21 01:11:00.000000','2025-02-21 01:11:00.240867',10,10000,26,8,42,'2025년 1회 헬스한판 뜨실분 구합니다...','2025년 1회 헬스한판','멀티캠퍼스 헬스장','2025년 1회 헬스한판 뜨실분 구합니다','CLOSED'),('2025-02-20 16:10:45.238681',1,'2025-02-21 01:11:00.000000','2025-02-21 01:11:00.407594',123,123,26,9,42,'...','빨리 만나서 헬스 뜨실분','ㅇ','ㄱㄱ','CLOSED'),('2025-02-20 16:11:05.294030',1,'2025-02-21 02:10:00.000000','2025-02-20 16:11:05.294030',19,30000,20,10,35,'...','역삼역 번개','멀티캠퍼스 역삼','저녁먹어요!','AD_HOC'),('2025-02-20 16:11:56.805612',1,'2025-02-21 01:12:00.000000','2025-02-21 01:12:00.296478',123,123,26,11,42,'...','헬스 한판 뜨실분','헬스 한판 뜨실분','헬스 한판 뜨실분','CLOSED'),('2025-02-20 16:12:12.840522',3,'2025-02-21 01:13:00.000000','2025-02-21 01:13:00.317924',123,123,26,12,42,'...','지금 당장 헬스 뜨실분','123','헬스 한판 뜨실분','CLOSED'),('2025-02-20 16:19:33.933253',1,'2025-02-21 01:20:00.000000','2025-02-21 01:20:00.160670',10,1000,19,13,32,'...','등뼈감자탕','역삼역','등뼈감자탕 오후 6시에 먹습니다.','CLOSED'),('2025-02-20 16:19:34.486582',1,'2025-02-21 01:21:00.000000','2025-02-21 01:21:00.207146',5,50000,26,14,43,'...','역삼역 헬스 배틀','멀티캠퍼스 역삼','감자랑 배틀하실 분 구합니다.','CLOSED'),('2025-02-20 16:46:24.110924',1,'2025-02-21 01:47:00.000000','2025-02-21 01:47:00.157514',10,100,19,15,32,'...','소고기먹는일정','역삼역','맛있겠네요','CLOSED'),('2025-02-20 16:51:09.423748',1,'2025-02-21 01:52:00.000000','2025-02-21 01:52:00.228041',10,100,19,16,32,'...','돼지고기먹자','역삼역','김치찌개 어떤데','CLOSED'),('2025-02-20 17:09:32.311456',1,'2025-02-21 02:10:00.000000','2025-02-20 17:09:32.311456',10,10000,19,17,32,'...','고기는피로회복에도좋다','우리집','고기는 프로회복에도 좋다','REGULAR');
/*!40000 ALTER TABLE `team_schedule` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  2:38:33
