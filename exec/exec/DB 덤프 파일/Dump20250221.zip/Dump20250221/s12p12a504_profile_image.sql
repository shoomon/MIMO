-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: mimodb.c95ejkmsx345.ap-northeast-2.rds.amazonaws.com    Database: s12p12a504
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `profile_image`
--

DROP TABLE IF EXISTS `profile_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profile_image` (
  `profile_image_id` bigint NOT NULL AUTO_INCREMENT,
  `team_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `profile_uri` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_type` enum('TEAM','USER') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`profile_image_id`),
  KEY `idx_profile_img_type_team_uri` (`image_type`,`team_id`,`profile_uri`),
  KEY `idx_profile_img_type_user_uri` (`image_type`,`user_id`,`profile_uri`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_image`
--

LOCK TABLES `profile_image` WRITE;
/*!40000 ALTER TABLE `profile_image` DISABLE KEYS */;
INSERT INTO `profile_image` VALUES (1,NULL,1,'https://lh3.googleusercontent.com/a/ACg8ocKferjitVS6W1Sj3kp3CfFPAulVVX7v9-DuqDfSs5EzpsXIJ_c=s96-c','USER'),(2,1,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/04cf9383-0efc-4dcc-8857-0bde1eaee6c9.webp','TEAM'),(3,NULL,2,'https://lh3.googleusercontent.com/a/ACg8ocLk6IjelzwK9vKdr7HRvKPGrhoxd_mQnQGs399-weFUOsCzdVw=s96-c','USER'),(4,NULL,3,'https://lh3.googleusercontent.com/a/ACg8ocJZJVDvrGeT6e-wNPc7Rn61KJwCKtZ7FEiCBHfqJmXFAWsA6g=s96-c','USER'),(5,2,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/25b9b98e-2d0e-48d6-941b-cb68e3774b88.webp','TEAM'),(6,3,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/c0a0372b-48f9-4de9-bd79-38c2a8c74645.webp','TEAM'),(7,NULL,4,'https://lh3.googleusercontent.com/a/ACg8ocJM2lK4U74yXMgVBUIT5swnniLFcDTkRikaEl-YAvKRKfN-Aw=s96-c','USER'),(8,4,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/91914b6a-52ec-4d08-a4af-d1c3e063069a.webp','TEAM'),(9,NULL,5,'https://lh3.googleusercontent.com/a/ACg8ocIdQbb0oRBQtUYeFpXKJKQtR_w73H6mgBbh1jwMRXKpa5bAyQ=s96-c','USER'),(18,NULL,6,'https://lh3.googleusercontent.com/a/ACg8ocIkbAJYBPq3AJksZxdKYXwovLR-9GLmozMKtQ5NGw1LWPi1Bw=s96-c','USER'),(27,5,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/f56e5bd6-c6ba-4f78-b6ab-2f59e927cf2c.png','TEAM'),(30,6,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/bb98ebd6-de51-48d9-bfe9-04f02ffbe3d8.png','TEAM'),(31,NULL,7,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','USER'),(32,7,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','TEAM'),(47,8,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/8832cb27-1000-4ead-a89e-a75cb2beb52b.jpg','TEAM'),(48,9,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','TEAM'),(72,12,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/b9d7c84b-e7b1-43d4-bd2d-9d9fbd47a651.jpg','TEAM'),(102,13,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/9073ac31-e687-44b8-a19c-d59d112e6208.jpg','TEAM'),(103,14,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','TEAM'),(104,NULL,8,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','USER'),(105,16,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','TEAM'),(106,NULL,9,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','USER'),(107,NULL,11,'https://lh3.googleusercontent.com/a/ACg8ocJCbo09M8mG1qjHlENXD_YDlqqc55V-jKKHB1WfmINiLDPVU6on=s96-c','USER'),(108,NULL,12,'https://lh3.googleusercontent.com/a/ACg8ocK91KjkrH-CAPLL6ppTbghGfcudOz2iO01lbcSBh9ktRrNnfg=s96-c','USER'),(109,17,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/ad266692-62c9-4711-8ca3-0546d789ae33.png','TEAM'),(110,NULL,13,'https://lh3.googleusercontent.com/a/ACg8ocL4g-uMf-RPjjznbu2bOkHpGM4L7ijCGb27yOmHc6LQYTjf2g=s96-c','USER'),(111,18,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/a09365ab-3291-49a9-ad93-0aa41301166a.jpg','TEAM'),(112,19,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/8e703b20-7cb1-4a3a-896b-783406c3a833.jpg','TEAM'),(113,NULL,14,'https://lh3.googleusercontent.com/a/ACg8ocJFAsX-twnSxUssTAfsO_tco4qwYJ60jkmb_GhOn_e2gC-rWg=s96-c','USER'),(114,20,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/5e24be5f-d408-4207-8c8f-11e5e7b283fb.png','TEAM'),(115,21,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/baeb974e-75d8-4200-8969-0cd98cb26cc8.jpg','TEAM'),(123,25,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/42a90caf-ee23-4991-9b9d-aa0d896e9c57.jpg','TEAM'),(124,NULL,15,'https://lh3.googleusercontent.com/a/ACg8ocI-SFdVgAvBqWdMSym0Ncs7VKiotVXPW8pC-8B08gHnAvS6Ng=s96-c','USER'),(125,26,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/76777a66-9ec9-465c-8d9c-f4a949b39a0c.webp','TEAM'),(126,NULL,16,'https://lh3.googleusercontent.com/a/ACg8ocL2KHZXNpulRR-gAdWvScJxM35t0gWXVCahENTv-IQz91Q2cQ=s96-c','USER'),(127,NULL,17,'https://lh3.googleusercontent.com/a/ACg8ocJAfKA_ei_ZtyZFJ5GrWqH84rMZhPWJRC4pcKv-hExovhKjRw=s96-c','USER'),(129,28,NULL,'https://bisang-mimo-bucket.s3.ap-northeast-2.amazonaws.com/14f86304-4ec7-4194-9f23-08f056e01631.jpg','TEAM');
/*!40000 ALTER TABLE `profile_image` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  2:38:41
