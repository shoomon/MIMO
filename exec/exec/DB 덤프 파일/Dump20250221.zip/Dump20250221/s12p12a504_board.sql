-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: mimodb.c95ejkmsx345.ap-northeast-2.rds.amazonaws.com    Database: s12p12a504
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `board_description_id` bigint DEFAULT NULL,
  `board_id` bigint NOT NULL AUTO_INCREMENT,
  `board_like` bigint NOT NULL,
  `board_view_count` bigint NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `last_modified_at` datetime(6) DEFAULT NULL,
  `team_board_id` bigint NOT NULL,
  `team_id` bigint NOT NULL,
  `team_user_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `board_title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`board_id`),
  UNIQUE KEY `UK1opsfswmkprn2f02ryu5d2t6u` (`board_description_id`),
  KEY `idx_board_user` (`user_id`),
  KEY `idx_board` (`team_board_id`,`board_id` DESC),
  CONSTRAINT `FKo70lqwgrntw6myka06a1o1th4` FOREIGN KEY (`board_description_id`) REFERENCES `board_description` (`board_description_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (1,1,0,0,'2025-02-20 18:36:15.485639','2025-02-20 18:36:15.485639',6,6,6,1,'나명규'),(2,2,0,0,'2025-02-20 18:36:26.341240','2025-02-20 18:36:26.341240',6,6,6,1,'나명규'),(3,3,1,7,'2025-02-20 12:23:40.097577','2025-02-20 12:23:40.097577',9,9,23,11,'ㅋㅋ'),(4,4,0,0,'2025-02-20 12:41:33.642239','2025-02-20 12:41:33.642239',13,16,26,6,'안녕하세요'),(5,5,0,4,'2025-02-20 12:41:59.590633','2025-02-20 12:41:59.590633',13,16,26,6,'안녕하세요'),(6,6,1,5,'2025-02-20 12:42:32.102522','2025-02-20 12:42:32.102522',13,16,26,6,'안녕하세요'),(7,7,0,12,'2025-02-20 12:42:45.465387','2025-02-20 12:42:45.465387',13,16,26,6,'안ㄴ녕'),(8,8,0,0,'2025-02-20 15:03:55.919593','2025-02-20 15:03:55.919593',18,19,32,12,'역삼역 대우부대찌개 맛있습니다.'),(9,9,0,2,'2025-02-20 15:05:43.881659','2025-02-20 15:05:43.881659',20,20,33,14,'초보용 목도리 뜨기'),(10,10,0,0,'2025-02-20 15:07:10.789242','2025-02-20 15:07:10.789242',20,20,33,14,'해링본 목도리'),(11,11,0,2,'2025-02-20 15:08:50.424261','2025-02-20 15:08:50.424261',17,20,33,14,'뜨개질함뜨까 규칙'),(12,12,0,2,'2025-02-20 15:10:31.711404','2025-02-20 15:10:31.711404',18,19,32,12,'치킨에 막국수를 파는 집이 있다??'),(13,13,0,0,'2025-02-20 15:16:36.206751','2025-02-20 15:16:36.206751',18,19,32,12,'또순이네 된장찌개'),(14,14,0,0,'2025-02-20 15:37:53.459367','2025-02-20 15:37:53.459367',15,18,37,6,'안녕하세요!'),(15,15,0,0,'2025-02-20 16:29:03.874335','2025-02-20 16:29:03.874335',27,28,50,6,'안녕하세요!'),(16,16,0,0,'2025-02-20 16:29:23.590762','2025-02-20 16:29:23.590762',27,28,50,6,'아름다운 밥이에요');
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-21  2:38:34
